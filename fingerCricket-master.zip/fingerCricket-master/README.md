# fingerCricket
This is a game based on JS. Just for fun!
